<?php

namespace Directus\Authentication\Exception;

use Directus\Exception\ErrorException;

class UnknownUserAttributeException extends ErrorException
{

}
