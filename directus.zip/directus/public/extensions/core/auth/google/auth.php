<?php

return [
    'provider' => \Directus\Authentication\Sso\Provider\google\Provider::class
];
